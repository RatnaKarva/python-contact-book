# Python Contact Book

A beginner-friendly Python contact book with options to add, search, view, and delete contacts.

## Features
- Add contacts
- Search contacts
- Show all contacts
- Delete contacts
- Exit the program

## Concepts Used
- Functions
- Lists
- `while` loops
- `for` loops
- `if-else`
- User input
- List methods

## Run
```bash
python contact_book.py
```
